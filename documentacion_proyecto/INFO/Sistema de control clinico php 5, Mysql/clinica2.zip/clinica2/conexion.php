<?php
$cn=mysql_connect("localhost","root","1234") or die("error en conexion");
$db=mysql_select_db("clinica")or die("error en db");
return($cn);
return($db);
?>
